package day_4;
import java.util.Scanner;
public class prefix {
public static void main(String[] args) {
   Scanner sc=new Scanner(System.in);
   int size=sc.nextInt(); 
   int arr[]=new int[size];
   for(int i=0;i<size;i++)
   {
    arr[i]=sc.nextInt();
   }
   int[]prefix=new int[size];
   prefix[0]=0;
    for(int i=1;i<size;i++)
    {
        prefix[i]=prefix[i-1]+arr[i-1];
    } 
    for(int ele:prefix)
    {
        System.out.print(ele+" ");
    }

}


}
