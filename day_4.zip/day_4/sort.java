package day_4;
import java.util.Scanner;
public class sort {
    public static void main(String[] args) {
        int arr[]={1,0,2,1,0,2,1,0,2,1};
        int zero =0,one=0,two=0;
        for(int i=0;i<10;i++)
        {
            Scanner sc = new Scanner(System.in);
            int a = sc.nextInt();
            if(a==0)
            {
                zero++;
            }
            else if(a==1)
            {
                one++;
            }
            else if(a==2)
            {
                two++;
            }
        }
        System.out.println("Zeros = " + zero);
        System.out.println("Ones = " + one);
        System.out.println("Twos = " + two);    


       


    }
}
