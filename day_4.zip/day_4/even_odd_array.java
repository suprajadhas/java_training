package day_4;

import java.util.Scanner;

public class even_odd_array{
    public static void main(String[]args){
    {
          int arr[] = {20,21,30,31,40,41,50,51};

        int left = 0, right = arr.length - 1;

        while (left < right) {
            if (arr[left] % 2 == 0) {
                left++;
            } else if (arr[right] % 2 != 0) {
                right--;
            } else {
                
                int temp = arr[left];
                arr[left] = arr[right];
                arr[right] = temp;
            }
        }

        for (int x : arr) {
            System.out.print(x + " ");
        }
            }
         

    }
}
