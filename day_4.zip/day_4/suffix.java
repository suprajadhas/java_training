package day_4;

import java.util.Scanner;
 
public class suffix {
   public static void main(String[] args) {
   Scanner sc=new Scanner(System.in);
   int size=sc.nextInt(); 
   int arr[]=new int[size];
   for(int i=0;i<size;i++)
   {
    arr[i]=sc.nextInt();
   }
   int[]suffix=new int[size];
   suffix[size-1]=0;
    for(int i=size-2;i>=0;i--)
    {
        suffix[i]=suffix[i+1]+arr[i+1];
    }
    for(int ele:suffix)
    {
        System.out.print(ele+" ");
    }
    
}

}
