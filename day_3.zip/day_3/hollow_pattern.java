import java.util.Scanner;

public class hollow_pattern {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        for(int row=1;row<=num;row++)
        {
            for(int star=1;star<=row;star++)
            {
                if(star==1 || star==row || row==num)
                {
                    System.out.print("*");
                }
                else
                {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }    
}
