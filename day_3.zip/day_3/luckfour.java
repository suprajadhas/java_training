import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int T = sc.nextInt();

        while (T-- > 0) {
            int N = sc.nextInt();
            int count = 0;

            while (N % 2 == 0) {
                count++;
                N /= 2;
            }

            if (count % 2 == 0)
                System.out.println(1);
            else
                System.out.println(0);
        }

        sc.close();
    }
}