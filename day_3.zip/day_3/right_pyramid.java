public class right_pyramid {
    public static void main(String[] args) {

        int num = 5;

        // Upper part
        for (int row = 1; row <= num; row++) {

            // Spaces
            for (int col = 1; col <= num - 1; col++) {
                System.out.print(" ");
            }

            // Stars
            for (int col = 1; col <= row; col++) {
                System.out.print("*");
            }

            System.out.println();
        }

        // Lower part
        for (int row = num - 1; row >= 1; row--) {

            // Spaces
            for (int col = 1; col <= num - 1; col++) {
                System.out.print(" ");
            }

            // Stars
            for (int col = 1; col <= row; col++) {
                System.out.print("*");
            }

            System.out.println();
        }
    }
}
