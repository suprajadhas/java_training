import java.util.Scanner;
public class array_operations {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int arr[] = new int[n];
        
        for(int i=0;i<n;i++)
        {
            arr[i] = sc.nextInt();
        }
        int sum=0;
        int max=arr[0];
        int min=arr[0];
        for(int i=0;i<n;i++)
        {
            sum+=arr[i];       
            int avg = sum/n;
            System.out.println(avg);
        
            if(arr[i]>max)
            {
                max = arr[i];
            }
            if(arr[i]<min)
            {
                min = arr[i];
            }
        }
        System.out.println("Maximum: " + max);
        System.out.println("Minimum: " + min);

    }
}
