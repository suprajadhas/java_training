import java.util.Scanner;

public class full_pyramid {
        public static void main(String[] args) {
            
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        for(int row=1;row<=num;row++)
        {
            for(int spc=1;spc<=num-row;spc++)
            {
                System.out.print(" ");
            }
            for(int star=1;star<=row*2-1;star++)
            {

                System.out.print("*");
            }
            System.out.println();
        }
    }
}
