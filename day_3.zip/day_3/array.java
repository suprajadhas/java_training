import java.util.*;

public class array {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        int size = s.nextInt();
        int[] a = new int[size];

        // Input
        for (int i = 0; i < size; i++) {
            a[i] = s.nextInt();
        }

        // Store last element
        int temp = a[size - 1];

        // Shift elements right
        for (int j = size - 1; j > 0; j--) {
            a[j] = a[j - 1];
        }

        // Place last element at first
        a[0] = temp;

        // Output
        for (int ele : a) {
            System.out.print(ele + " ");
        }
    }
}