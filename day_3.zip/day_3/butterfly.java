import java.util.Scanner;

public class butterfly {
    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);
        int num = s.nextInt();

        
        for (int row = 1; row <= num; row++) {

            
            for (int col = 1; col <= row; col++) {
                System.out.print("*");
            }

            
            for (int col = 1; col <= 2 * (num - row); col++) {
                System.out.print(" ");
            }

            
            for (int col = 1; col <= row; col++) {
                System.out.print("*");
            }

            System.out.println();
        }

        
        for (int row = num; row >= 1; row--) {

            
            for (int col = 1; col <= row; col++) {
                System.out.print("*");
            }

        
            for (int col = 1; col <= 2 * (num - row); col++) {
                System.out.print(" ");
            }

            for (int col = 1; col <= row; col++) {
                System.out.print("*");
            }

            System.out.println();
        }
    }
}