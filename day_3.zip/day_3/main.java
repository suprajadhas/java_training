import java.util.*;
public class main {
    public static void main(String[] args) {
        int num;
        Scanner sc = new Scanner(System.in);
        num = sc.nextInt();
        for(int row=1;row<=num;row++)
        {
            for(int spc=1;spc<=num-row;spc++)
            {
                System.out.print(" ");
            }
            for(int star=1;star<=row;star++)
            {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}