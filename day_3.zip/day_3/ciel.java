import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int T = sc.nextInt();

        while (T-- > 0) {

            int p = sc.nextInt();
            int count = 0;

            while (p > 0) {

                if (p >= 2048) {
                    p -= 2048;
                    count++;
                } else {

                    int power = 1;

                    while (power * 2 <= p) {
                        power *= 2;
                    }

                    p -= power;
                    count++;
                }
            }

            System.out.println(count);
        }

        sc.close();
    }
}