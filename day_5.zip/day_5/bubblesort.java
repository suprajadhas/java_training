package day_5;

public class bubblesort {
   
    public static void main(String[] args) {
        int arr[] = {5, 3, 2, 4};
        int n = arr.length;
        boolean swapped;

        for (int i = 0; i < n - 1; i++) {
            swapped = false;

            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    swapped = true;
                }
            }

            if (!swapped) break; 
        }

        for (int x : arr) {
            System.out.print(x + " ");
        }
    }
}

