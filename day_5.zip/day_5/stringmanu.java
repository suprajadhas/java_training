package day_5;
import java.util.Scanner;
public class stringmanu {
    public static void main(String[] args) {
        
        String str = "This is a sample string.";
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            if (ch >= 'a' && ch <= 'z') {
                System.out.print((char) (ch - 32));
            } else if (ch >= 'A' && ch <= 'Z') {
                System.out.print((char) (ch + 32));
            } else {
                System.out.print(ch);
            }
        }
   
   
   
   
   
    }
}