public class Main {
    public static void main(String[] args) {

        int[] nums = {3, 2, 2, 3, 4, 2};
        int val = 2;

        int k = 0;

        for (int i = 0; i < nums.length; i++) {
            if (nums[i] != val) {
                nums[k] = nums[i];
                k++;
            }
        }

        System.out.println("Number of remaining elements: " + k);

        System.out.print("Array after removing " + val + ": ");
        for (int i = 0; i < k; i++) {
            System.out.print(nums[i] + " ");
        }
    }
}