package day_5;
import java.util.Arrays;

public class twosum {
    public static void main(String[] args) {
        int[] nums = {2, 7, 11, 15};
        int target = 9;
        int[] n = new int[2];
        for(int i=0;i<nums.length;i++)
        {
            for(int j=i+1;j<nums.length;j++)
            {
                if(nums[i]+nums[j]==target)
                {
                    n[0]=i;
                    n[1]=j;
                    System.out.println(Arrays.toString(n));
                }
            }
        }
       
    }
}

