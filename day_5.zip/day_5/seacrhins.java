public class Main {
    public static void main(String[] args) {

        int[] nums = {1, 3, 5, 6};
        int target = 5;

        int index = nums.length; // Default: insert at the end

        for (int i = 0; i < nums.length; i++) {
            if (nums[i] >= target) {
                index = i;
                break;
            }
        }

        System.out.println("Search Insert Position: " + index);
    }
}