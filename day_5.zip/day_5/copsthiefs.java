import java.util.*;

class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int T = sc.nextInt();

        while (T-- > 0) {

            int M = sc.nextInt(); // total houses
            int X = sc.nextInt(); // number of cops
            int Y = sc.nextInt(); // range of each cop

            boolean[] houses = new boolean[M + 1];

            for (int i = 0; i < X; i++) {

                int cop = sc.nextInt();

                int left = Math.max(1, cop - X * 0 + cop - Y);
                int right = Math.min(M, cop + Y);

                for (int j = left; j <= right; j++) {
                    houses[j] = true;
                }
            }

            int count = 0;

            for (int i = 1; i <= M; i++) {
                if (!houses[i]) {
                    count++;
                }
            }

            System.out.println(count);
        }

        sc.close();
    }
}