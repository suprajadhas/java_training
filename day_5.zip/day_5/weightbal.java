import java.util.*;

class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int T = sc.nextInt();

        while (T-- > 0) {

            int W1 = sc.nextInt();
            int W2 = sc.nextInt();
            int X = sc.nextInt();
            int Y = sc.nextInt();

            if ((W2 - W1 >= X && W2 - W1 <= Y) ||
                (W1 - W2 >= X && W1 - W2 <= Y)) {
                
                System.out.println("YES");
            } 
            else {
                System.out.println("NO");
            }
        }

        sc.close();
    }
}