
import java.util.*;

public class SearchInList {
    public static void main(String[] args) {
        List<String> list = Arrays.asList(
            "Hii", "hello", "welcome", "say", "I", "bye", "to", "stress"
        );

        String search = "SAY";
        boolean found = false;

        for (String word : list) {
            if (word.equalsIgnoreCase(search)) {
                found = true;
                break;
            }
        }

        if (found) {
            System.out.println(search + " --> found");
        } else {
            System.out.println(search + " --> not found");
        }
    }
}
    

