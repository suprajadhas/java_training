public class Camelase {
    public static void main(String[] args) {
        String input = "thisIsAutomationEra";

        
        String result = input.replaceAll("([a-z])([A-Z])", "$1 $2");

        
        result = result.substring(0, 1).toUpperCase() + result.substring(1);

        System.out.println(result);
    }
}