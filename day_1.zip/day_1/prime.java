import java.util.Scanner;
public class prime {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int num = sc.nextInt();
        for(int i=2;i*i<=num;i++){
            if(num%i==0){
                break;
            }
            if(i*i==num){
                System.out.println(num + " NOT PRIME");
                sc.close();
                return;
            }
        }
        System.out.println(num + " PRIME");
        sc.close();
    }
}


