import java.util.Scanner;
public class cals {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double a = sc.nextDouble();
        char op = sc.next().charAt(0);
        double b = sc.nextDouble();

        double result = 0;

        switch(op) {
            case '+': result = a + b; break;
            case '-': result = a - b; break;
            case '*': result = a * b; break;
            case '/':
                if (b != 0)
                    result = a / b;
                else {
                    System.out.println("Cannot divide by zero");
                    sc.close();
                    return;
                }
                break;
            default:
                System.out.println("Invalid operator");
                sc.close();
                return;
        }

        System.out.println(result);
        sc.close();
    }
}
