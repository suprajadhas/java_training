import java.util.Scanner;
public class greater_num {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int c = sc.nextInt();

    if (a > b) 
    {
       
        if (a > c)
        {
           System.out.println("Greatest: " + a);
        } 
        else 
        {
            System.out.println("Greatest: " + c);
        }
    }
    else {
         if (b > c) 
            {
            System.out.println("Greatest: " + b);
    } 
    else {
        System.out.println("Greatest: " + c);
        }
     } 
}
}