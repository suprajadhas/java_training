import java.util.Scanner;
public class adam {
     static int reverse(int n) {
        int rev = 0;
        while(n > 0) {
            rev = rev * 10 + (n % 10);
            n /= 10;
        }
        return rev;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        int square = n * n;
        int rev = reverse(n);
        int revSquare = rev * rev;
        int finalRev = reverse(revSquare);

        if(square == finalRev) {
            System.out.println("Adam Number ");
        } else {
            System.out.println("Not an Adam Number ");
        }
    }
}

