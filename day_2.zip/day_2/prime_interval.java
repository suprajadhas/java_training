import java.util.Scanner;
public class prime_interval {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int a = s.nextInt();
        int b = s.nextInt();

    for(int i=a;i<=b;i++){
       
        for(int j=2;j*j<=i;j++){
            if(i%j==0){
                
                break;
            }
        }
        if(i*i==i){
            System.out.println(i);
        }
    }
}
